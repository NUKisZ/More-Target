//
//  ViewController.m
//  aaa
//
//  Created by gongrong on 2018/9/4.
//  Copyright © 2018年 张坤. All rights reserved.
//

#import "ViewController.h"
#import "Color.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [Color color];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
