//
//  ViewController.m
//  bbb
//
//  Created by gongrong on 2018/9/4.
//  Copyright © 2018年 张坤. All rights reserved.
//

#import "ViewController.h"
#import "Color.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [Color color];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
