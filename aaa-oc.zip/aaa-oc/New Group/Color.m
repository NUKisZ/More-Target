//
//  Color.m
//  aaa
//
//  Created by gongrong on 2018/9/4.
//  Copyright © 2018年 张坤. All rights reserved.
//

#import "Color.h"

@implementation Color
+ (UIColor *)color{
#if AppType==1
    return [UIColor greenColor];
#elif AppType==2
    return [UIColor redColor];
#else
    return [UIColor grayColor];
#endif
}
@end
