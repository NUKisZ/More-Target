//
//  Color.swift
//  aaa
//
//  Created by gongrong on 2018/9/4.
//  Copyright © 2018年 张坤. All rights reserved.
//

import UIKit

class Color: NSObject {
    public class func colco()->UIColor{
        #if AppType1
        return UIColor.red
        #elseif AppType2
        return UIColor.blue
        #else
        return UIColor.green
        #endif
        
    }

}
